package com.demo.web;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/DataServlet")
public class DataServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		ArrayList<Employee> list = new ArrayList<>();
		list.add(new Employee(100, "James", "London", 56000));
		list.add(new Employee(101, "Scott", "London", 56000));
		list.add(new Employee(102, "Kiran", "Chennai", 56000));
		list.add(new Employee(103, "Srinu", "Pune", 56000));
		list.add(new Employee(104, "Balu", "Bangalore", 56000));
		list.add(new Employee(105, "Nitin", "Hyderabad", 56000));
		list.add(new Employee(106, "Maria", "London", 56000));
		request.setAttribute("data", list);
		request.getRequestDispatcher("/showData.jsp").forward(request, response);

	}

}
