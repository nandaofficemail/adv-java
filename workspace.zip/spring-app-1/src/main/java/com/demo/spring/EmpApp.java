package com.demo.spring;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class EmpApp {

	@Autowired
	Dao dao;

	public String registerEmp(int id, String name, String city, double sal) {
		String message = dao.saveEmp(new Employee());
		return message;
	}
}
