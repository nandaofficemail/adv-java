package com.demo.spring.dao.impl;

import org.springframework.stereotype.Component;

import com.demo.spring.Dao;
import com.demo.spring.Employee;

@Component
public class DaoJdbcImpl implements Dao {

	@Override
	public String saveEmp(Employee e) {
		// TODO Auto-generated method stub
		return "JDBC: Emplyee saved";
	}

}
