package com.demo.spring;

public class Employee {

}
