package com.demo.web;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/process")
public class ProcessEmp extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		// id=100&name=aa&addr=Hyd&sal=23000
		String id = request.getParameter("id");
		String name = request.getParameter("name");
		String address = request.getParameter("addr");
		String salary = request.getParameter("sal");

		out.print("<h2> The Emp Details : " + id + " " 
		+ name + " " + address + " " + salary+"</h1>");

	}

}
