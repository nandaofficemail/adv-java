package com.demo.jpa;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

public class JPAQuery {

	public static void main(String[] args) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpa1");
		EntityManager em = emf.createEntityManager();
		EntityTransaction tx = em.getTransaction();

		try {

			Query query = em.createQuery("select E from Employee E");
			query.setMaxResults(10).setFirstResult(4);
			List<Employee> empList = query.getResultList();

			for (Employee e : empList) {
				System.out.println(e.getEmpId() + " " + e.getName() + " " + e.getCity() + " " + e.getSalary());
			}

			
			
			Query query1 = em.createQuery("select e.name,e.city from Employee e");
			List<Object[]> data = query1.getResultList();
			for (Object[] o : data) {
				String name = (String) o[0];
				String city = (String) o[1];
				System.out.println(name + " " + city);
			}

		} catch (Exception e) {
			// tx.rollback();
			e.printStackTrace();
		} finally {
			emf.close();
		}

	}

}
