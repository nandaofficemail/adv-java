package com.demo.web;

import java.io.IOException;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/success2")
public class Success2 extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html");
		response.getWriter().write("<h1>Login Successful..Enjoy</h1>");
		response.getWriter().write("<h1>" + request.getParameter("username") + "</h1>");
		ServletContext ctx = request.getServletContext();
		response.getWriter().write("<h1>" + ctx.getInitParameter("driver") + "</h1>");
		response.getWriter().write("<h1>" + request.getAttribute("myname") + "</h1>");

	}

}
