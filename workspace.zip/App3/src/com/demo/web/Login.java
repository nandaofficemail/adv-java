package com.demo.web;

import java.io.IOException;

import javax.jws.soap.InitParam;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebInitParam;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/login")
@WebInitParam(name="n1",value="Shantanu")

public class Login extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	@Override
	public void init(ServletConfig config) throws ServletException {
		super.init(config);
		String name=config.getInitParameter("n1");
		System.out.println(name+" from Init method...");
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String userName = request.getParameter("username");
		String password = request.getParameter("password");

		if (userName.equals(password)) {
			RequestDispatcher rd = request.getRequestDispatcher("/success");
			String name=getServletConfig().getInitParameter("n1");
			request.setAttribute("myname","Joker");
			rd.forward(request, response);
		} else {
			RequestDispatcher rd = request.getRequestDispatcher("/failure");
			rd.forward(request, response);
			// response.sendRedirect("http://www.google.co.in");
		}
	}

}
