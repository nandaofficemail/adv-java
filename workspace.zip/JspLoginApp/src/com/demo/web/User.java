package com.demo.web;

public class User {

	private String userId;
	private String userName;
	private String married;
	private String details;

	public String getDetails() {
		return userId + " " + userName + " " + married;
	}

	public User() {
		// TODO Auto-generated constructor stub
	}

	public String getUserName() {
		return this.userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getMarried() {
		return married;
	}

	public void setMarried(String married) {
		this.married = married;
	}

	public String getMeSomething() {
		return "You are in Bean ";
	}
}
