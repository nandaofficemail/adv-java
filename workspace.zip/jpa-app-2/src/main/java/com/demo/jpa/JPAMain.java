package com.demo.jpa;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class JPAMain {

	public static void main(String[] args) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpa1");
		EntityManager em = emf.createEntityManager();
		EntityTransaction tx = em.getTransaction();

		try {
			tx.begin();
			Dept dept= new Dept(10, "Accounts", "Ramesh");
			em.persist(dept);
			
			Employee e1 = new Employee(222, "Scott", "England", 45000);
			Employee e2 = new Employee(221, "James", "London", 55000);
			e1.setDept(dept);
			e2.setDept(dept);
			
			em.persist(e1);
			em.persist(e2);
			
			tx.commit();
		} catch (Exception e) {
			tx.rollback();
			e.printStackTrace();
		} finally {
			emf.close();
		}

	}

}
