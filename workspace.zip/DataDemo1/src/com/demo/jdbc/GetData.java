package com.demo.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class GetData {

	public static void main(String[] args) {
		Connection conn = null;
		Statement st = null;
		ResultSet rs = null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/springdb",
					"root", "root");
			st = conn.createStatement();
			rs = st.executeQuery("select * from emp");
			while (rs.next()) {
				String data = rs.getInt("EMPNO") + " " + 
			rs.getString("NAME") + " " + rs.getString("ADDRESS") + " "
						+ rs.getDouble("SALARY");
				System.out.println(data);
			}
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				rs.close();
				st.close();
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}

		}

	}

}
