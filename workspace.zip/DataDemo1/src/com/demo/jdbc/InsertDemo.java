package com.demo.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.apache.log4j.Logger;

public class InsertDemo {

	public static void main(String[] args) {
		Connection conn = null;
		PreparedStatement pst = null;
		Logger logger=Logger.getLogger("com.demo.InsertDemo");
		try {
			Class.forName("com.mysql.jdbc.Driver");
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/springdb", "root", "root");
			pst = conn.prepareStatement("insert into emp(empno,name,address,salary)"
					+ " values(?,?,?,?)");
			pst.setInt(1, 203);
			pst.setString(2, "Shankar");
			pst.setString(3, "Delhi");
			pst.setDouble(4, 76000);
			int row=pst.executeUpdate();
			if(row!=0){
				System.out.println("Rows Effected : "+row);
			}
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			logger.info("You have Duplicat PK Error");
			logger.debug("You have Duplicat PK Error: take care");

			//e.printStackTrace();
		} finally {
			try {
				
				pst.close();
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}

		}

	}

}
