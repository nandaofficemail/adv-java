package com.demo.web;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/S1")
public class S1 extends HttpServlet {
	private static final long serialVersionUID = 1L;

	//HashMap<String, String> cart = null;

	@Override
	public void init(ServletConfig config) throws ServletException {
		//cart = new HashMap<>();
		System.out.println("Cart Created...");
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		String itemName = request.getParameter("itemName");
		String itemCount = request.getParameter("itemCount");

		HttpSession session = request.getSession();
		HashMap<String, String> cart=(HashMap<String, String>)session.getAttribute("cart");
		
		if(cart==null){
			cart=new HashMap<>();
		}
		cart.put(itemName, itemCount);
		session.setAttribute("cart", cart);

		out.write("<h1>Shopping Cart</h1> " + "<form action=\"S1\" method=\"post\">"
				+ "Item Name:<input type=\"text\" name=\"itemName\"><br />"
				+ " Item Count:<input type=\"text\" name=\"itemCount\"><br />"
				+ "<input type=\"submit\" value=\"Next>>\"><br />" + "</form>");
		out.println("<h2>Session ID: "+session.getId()+"</h2>");
		out.print("<a href=\"CheckOutServlet\">Checkout</a>");
	}

}
