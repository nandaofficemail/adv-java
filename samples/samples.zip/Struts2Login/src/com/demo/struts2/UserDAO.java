package com.demo.struts2;

public interface UserDAO {
	public String getPassword(String name);
}
